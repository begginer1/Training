package com.hexaware.demo;

import org.springframework.stereotype.Component;

@Component("smsService")
public class SMSService implements IService {

	@Override
	public void message(String msg) {
		// TODO Auto-generated method stub
		System.out.println("SMS service:"+msg);
		
	}

}
