package com.hexaware.demo;

public interface IService {

	public void message(String msg);
}
