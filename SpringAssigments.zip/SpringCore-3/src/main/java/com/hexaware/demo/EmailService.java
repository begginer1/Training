package com.hexaware.demo;

import org.springframework.stereotype.Component;

@Component
public class EmailService implements IService {

	@Override
	public void message(String msg) {
		System.out.println("Email service:"+msg);

	}

}
