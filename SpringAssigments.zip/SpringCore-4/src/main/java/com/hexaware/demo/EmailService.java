package com.hexaware.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class EmailService {
	IDataSource ob;
	
	@Autowired
	public EmailService(IDataSource ob)
	{
		this.ob=ob;
	}
	
	
	public void sendEmail()
	{
		ob.returnConection();
	}

	
	
}
