package com.hexaware.demo;

import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Component;

@Component
@Primary
public class MySqlDatabase implements IDataSource{

	@Override
	public void returnConection() {
		System.out.println("MysqlDatabase");
		
	}

}
