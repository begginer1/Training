package com.hexaware.demo;

import org.springframework.stereotype.Component;

@Component
public class PostgressDataBase implements IDataSource{
	
	@Override
	public void returnConection() {
		System.out.println("MysqlDatabase"); 
		
	}

}
