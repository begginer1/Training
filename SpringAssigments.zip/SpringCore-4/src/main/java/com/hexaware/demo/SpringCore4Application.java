package com.hexaware.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringCore4Application {

	public static void main(String[] args) {
		SpringApplication.run(SpringCore4Application.class, args);
	}

}
