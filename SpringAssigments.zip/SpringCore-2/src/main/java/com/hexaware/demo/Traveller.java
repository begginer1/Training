package com.hexaware.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

@Component
public class Traveller {
 private Vehicle vehicle;
 @Autowired
 public Traveller(Vehicle obj)
 {
	 vehicle=obj;
 }
 
 public void startJourney()
 {
	 vehicle.move();
 }
}
