package com.hexaware.demo;

import org.springframework.stereotype.Component;

@Component
public class Bus implements Vehicle {

	@Override
	public void move() {
		System.out.print("Starting journey with Bus");

	}

}
