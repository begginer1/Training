package com.hexaware.demo;

import org.springframework.stereotype.Component;

@Component
public class Bike implements Vehicle {

	@Override
	public void move() {
		System.out.print("Starting journey with Bike");

	}

}
