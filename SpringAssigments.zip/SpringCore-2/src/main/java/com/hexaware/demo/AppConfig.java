package com.hexaware.demo;


import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

@ComponentScan("com.hexaware.demo")
@Configuration
public class AppConfig {


	
}
