package com.hexaware.demo;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
public class Client {
public static void main(String args[])
{

	ApplicationContext appcontext= new AnnotationConfigApplicationContext(AppConfig.class);
	Vehicle c=appcontext.getBean(Bike.class);
	c.move();
}
}
