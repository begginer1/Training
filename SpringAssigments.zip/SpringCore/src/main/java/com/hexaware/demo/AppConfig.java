package com.hexaware.demo;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class AppConfig {

	@Bean
	public Vehicle ReturnBikeObj()
	{
		return new Bike();
	}
	
	@Bean
	public Vehicle ReturnBusObj()
	{
		return new Bus();
	}
	
	@Bean
	public Vehicle ReturnCarObj()
	{
		return new Car();
	}
	
	@Bean(initMethod="init",destroyMethod="destroy")
	public Traveller Traveller()
	{
		return new Traveller(new Bike());
	}
	
}
