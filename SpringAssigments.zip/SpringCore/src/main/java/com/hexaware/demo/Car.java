package com.hexaware.demo;

public class Car implements Vehicle {

	@Override
	public void move() {
		System.out.print("Starting journey with Car");

	}

}
