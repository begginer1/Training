package com.hexaware.demo;

public class Bike implements Vehicle {

	@Override
	public void move() {
		System.out.print("Starting journey with Bike");

	}

}
