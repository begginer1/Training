package com.hexaware.demo;

import org.springframework.stereotype.Component;

@Component
public class Traveller {
 private Vehicle vehicle;
 public Traveller(Vehicle obj)
 {
	 vehicle=obj;
 }
 
 public void startJourney()
 {
	 vehicle.move();
 }
 
 public void init()
 {
	 System.out.println("Init");
 }
 
 public void destroy()
 {
	 System.out.println("destroyed");
 }
}
