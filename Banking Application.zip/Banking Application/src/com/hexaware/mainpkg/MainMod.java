package com.hexaware.mainpkg;

import java.util.ArrayList;

import com.hexaware.exception.AccountNotFoundException;

import com.hexaware.dao.IServiceProvider;
import com.hexaware.dao.ServiceProviderImpl;
import com.hexaware.dto.Bank;
import com.hexaware.dto.BankAccount;
import com.hexaware.exception.NegativeNumberException;

public class MainMod {
public static void main(String args[])
{
	BankAccount ob1=new BankAccount("Sachin","Savings",80000.0);
	BankAccount ob2=new BankAccount("XYZ","Current",25000.0);
	BankAccount ob3=new BankAccount("Naman","Savings",10000.0);
	ArrayList accountList=new ArrayList<BankAccount>();
	accountList.add(ob1);
	accountList.add(ob2);
	accountList.add(ob3);
	Bank bank=new Bank("ICICI",accountList);
	IServiceProvider service=new ServiceProviderImpl(bank);
	// checking Acount Balance
	try
	{
		System.out.println(service.checkbalance(1009));
	}
    catch(AccountNotFoundException e)
	{
    	System.out.println(e.getMessage());
	}
	
	
	
	try
	{
		System.out.println(service.withdraw(1003,2000));
	}
	catch(AccountNotFoundException e )
	{
		System.out.println(e.getMessage());
	}
	
	catch(NegativeNumberException e)
	{
		System.out.println(e.getMessage());
	}
	
	
	// Deposit
	try
	{
		System.out.println(service.deposit(1003,-2000));
	}
	catch(AccountNotFoundException e )
	{
		System.out.println(e.getMessage());
	}
	
	catch(NegativeNumberException e)
	{
		System.out.println(e.getMessage());
	}
	
	// create account
	try
	{
		System.out.println(service.createAccount(new BankAccount("navin","Savings",19000)));
	}
	catch(Exception e)
	{
		e.getStackTrace();
	}
	
	
	// Checking delting acount
		try
		{
			System.out.println(service.removeAccount(1003));
		}
		catch(AccountNotFoundException e )
		{
			System.out.println(e.getMessage());
		}
		

}
}
