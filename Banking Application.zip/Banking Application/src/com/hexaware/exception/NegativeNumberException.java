package com.hexaware.exception;

public class NegativeNumberException extends Exception{
 public NegativeNumberException(String msg)
 {
	 super(msg);
 }
}
