package com.hexaware.dto;

public class BankAccount {
private long accountId;
private String holdername;
private String type;
private double balance;
private static long  generatedAccount=1001;


public BankAccount(String holdername, String type, double balance) {
	this.accountId = generatedAccount++;
	this.holdername = holdername;
	this.type = type;
	this.balance = balance;
}
public long getAccountId() {
	return accountId;
}
public void setAccountId(long accountId) {
	this.accountId = accountId;
}
public String getHoldername() {
	return holdername;
}
public void setHoldername(String holdername) {
	this.holdername = holdername;
}
public String getType() {
	return type;
}
public void setType(String type) {
	this.type = type;
}
public double getBalance() {
	return balance;
}
public void setBalance(double balance) {
	this.balance = balance;
}
@Override
public String toString() {
	return "BankAccount [accountId=" + accountId + ", holdername=" + holdername + ", type=" + type + ", balance="
			+ balance + "]";
}
@Override
public boolean equals(Object obj) {
	// TODO Auto-generated method stub
	BankAccount b=(BankAccount)obj;
	return b.getAccountId()==accountId;
}




}
