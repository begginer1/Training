package com.hexaware.dao;

import com.hexaware.dto.BankAccount;
import com.hexaware.exception.AccountNotFoundException;
import com.hexaware.exception.NegativeNumberException;

public interface  IServiceProvider{

	public BankAccount  searchAccount(long accountNumber) throws AccountNotFoundException;
	public double checkbalance(long accountNumber)throws AccountNotFoundException;
 
	public boolean deposit(long accountNumber, double amount)throws AccountNotFoundException,NegativeNumberException;
 
	public boolean withdraw(long accountNumber, double amount)throws AccountNotFoundException,NegativeNumberException;

	public boolean createAccount(BankAccount newAcc);
	

	public boolean removeAccount(long accountNumber)throws AccountNotFoundException ;


	
}