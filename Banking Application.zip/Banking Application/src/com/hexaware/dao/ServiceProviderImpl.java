
package com.hexaware.dao;
import java.util.logging.Logger;

import com.hexaware.dto.Bank;
import com.hexaware.dto.BankAccount;
import com.hexaware.exception.AccountNotFoundException;
import com.hexaware.exception.NegativeNumberException;

public class ServiceProviderImpl implements IServiceProvider{
	private Bank myBank;
	//System.Logger logger = System.getLogger("MyLogger");
	private Logger logger=Logger.getLogger(ServiceProviderImpl.class.getName());
	public ServiceProviderImpl() {
		super();
		// TODO Auto-generated constructor stub
	}
 
	public ServiceProviderImpl(Bank myBank) {
		super();
		this.myBank = myBank;
	}
	@Override
	public BankAccount  searchAccount(long accountNumber) throws AccountNotFoundException{
		BankAccount reqAccount=null;
		for(BankAccount account:myBank.getAccountList()) {
			if(account.getAccountId()==accountNumber) {
				reqAccount=account;
				break;
			}
		}
		if(reqAccount==null)
			throw new AccountNotFoundException("Account Does Not exists");
		return reqAccount;

	}
	@Override
	public double checkbalance(long accountNumber) throws AccountNotFoundException {
		// TODO Auto-generated method stub
		double balanceAmount = -1;
		BankAccount reqAccount=null;
		reqAccount=searchAccount(accountNumber);
		balanceAmount=reqAccount.getBalance();
		return balanceAmount;
	}
 
	@Override
	public boolean deposit(long accountNumber, double amount) throws AccountNotFoundException,NegativeNumberException{
		// TODO Auto-generated method stub
		BankAccount reqAccount=null;
		boolean depostStatus=false;
		if(amount>0) {
			reqAccount=searchAccount(accountNumber);
			if(reqAccount==null){
				System.out.println("Account does not exist");
			}
		 else if(reqAccount!=null) {
			reqAccount.setBalance(reqAccount.getBalance()+amount);
			depostStatus=true;
		}
		}
		else
			throw new NegativeNumberException("Cannot Deposit negative Amount");
		logger.info( "Amount Deposied.");
		return depostStatus;
	}
 
	@Override
	public boolean withdraw(long accountNumber, double amount) throws AccountNotFoundException,NegativeNumberException {
		BankAccount reqAccount=null;
		boolean withdrawStatus=false;
		reqAccount=searchAccount(accountNumber);
		if(reqAccount.getBalance()<amount) {
			System.out.println("Insufficient funds...");
		}
		if(amount<0) {
			throw new NegativeNumberException("Cannot Withdraw negative Amount");
		}
		else {
			reqAccount.setBalance(reqAccount.getBalance()-amount);
			withdrawStatus=true;
		}
		logger.info("Amount Withdraw.");
		return withdrawStatus;
	}
 
	@Override
	public boolean createAccount(BankAccount newAcc) {
		// TODO Auto-generated method stub
		BankAccount lastAccObj=null;
		boolean status=false;
		lastAccObj=myBank.getAccountList().get(myBank.getAccountList().size()-1);
		BankAccount newAccObj=new BankAccount(newAcc.getHoldername(),newAcc.getType(),newAcc.getBalance());
		myBank.getAccountList().add(newAccObj);
		status=true;
		logger.info( "Acoount Created.");
		return status;
	}
 
	@Override
	public boolean removeAccount(long accountNumber) throws AccountNotFoundException {
		// TODO Auto-generated method stub
		BankAccount reqAccount=null;
		boolean removeStatus=false;
		reqAccount=searchAccount(accountNumber);
		this.myBank.getAccountList().remove(reqAccount);
		removeStatus=true;
		logger.info("Amount Removed.");
		return removeStatus;
	}


 
	
}
